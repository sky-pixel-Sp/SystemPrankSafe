@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle tidak ditemukan di PATH.
  echo Buka folder ini melalui Android Studio, pasang Android SDK 35 dan JDK 17, lalu Build ^> Build APK(s).
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK: app\build\outputs\apk\debug\app-debug.apk
