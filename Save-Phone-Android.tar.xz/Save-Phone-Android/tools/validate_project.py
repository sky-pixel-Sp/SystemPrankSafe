#!/usr/bin/env python3
"""Offline structural checks for the Save Phone Android source project."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

def main() -> int:
    xml_files = list(ROOT.rglob("*.xml"))
    for path in xml_files:
        ET.parse(path)

    manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
    manifest = ET.parse(manifest_path).getroot()
    application = manifest.find("application")
    if application is None:
        raise AssertionError("AndroidManifest.xml has no application element")

    components = []
    for tag in ("activity", "receiver", "service"):
        for node in application.findall(tag):
            name = node.attrib.get(ANDROID_NS + "name", "")
            if name.startswith("."):
                source = ROOT / "app/src/main/java/id/savephone/app" / (name[1:] + ".java")
                if not source.exists():
                    raise AssertionError(f"Missing source for manifest component {name}")
                components.append(name)

    admin_xml = ROOT / "app/src/main/res/xml/device_admin.xml"
    admin_text = admin_xml.read_text(encoding="utf-8")
    if "watch-login" not in admin_text or "force-lock" not in admin_text:
        raise AssertionError("Device Admin must declare watch-login and force-lock")

    required_files = [
        "app/src/main/java/id/savephone/app/MainActivity.java",
        "app/src/main/java/id/savephone/app/ProtectionAdminReceiver.java",
        "app/src/main/java/id/savephone/app/AlarmService.java",
        "app/src/main/java/id/savephone/app/SecurityStore.java",
        "app/src/main/java/id/savephone/app/NotificationHelper.java",
        "README.md", "BUILD_STATUS.md", "TEST_CHECKLIST.md",
    ]
    for relative in required_files:
        if not (ROOT / relative).is_file():
            raise AssertionError(f"Missing required file: {relative}")

    print(f"PASS: {len(xml_files)} XML files parse successfully")
    print(f"PASS: {len(components)} manifest components have matching Java sources")
    print("PASS: Device Admin policies and required project files are present")
    print("NOTE: This is a structural check, not an Android build or device test.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
