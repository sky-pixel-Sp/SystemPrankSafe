# Checklist QA perangkat

## Instalasi dan izin
- [ ] APK terpasang pada Android 8.0+.
- [ ] Notifikasi dapat diizinkan/ditolak tanpa aplikasi crash.
- [ ] Layar aktivasi Device Admin tampil dan dapat dibatalkan.
- [ ] Status admin pada dashboard sesuai dengan status sistem.

## Deteksi percobaan
- [ ] Dengan Device Admin aktif dan layar memakai PIN/pola/sandi, callback gagal masuk ke receiver.
- [ ] Riwayat mencatat waktu serta jumlah percobaan yang dilaporkan Android.
- [ ] Ambang 2, 3, dan 5 kali bekerja sesuai pilihan.
- [ ] Satu notifikasi per rangkaian percobaan muncul saat ambang tercapai.
- [ ] Kredensial benar setelah percobaan gagal mereset status peringatan.
- [ ] Perilaku pada versi Android dan OEM yang berbeda didokumentasikan.

## Alarm
- [ ] Tombol alarm di aplikasi menyalakan audio.
- [ ] Aksi alarm pada notifikasi dapat menyalakan audio.
- [ ] Aksi Matikan alarm menghentikan audio dan notifikasi berjalan.
- [ ] Alarm berhenti setelah 30/60/90 detik sesuai pilihan.
- [ ] Mode senyap, DND, volume, dan output audio diuji; jangan mengklaim alarm tak dapat dikecilkan.

## Tindakan pemilik
- [ ] `lockNow()` bekerja setelah admin aktif.
- [ ] Dialog verifikasi pemilik memanggil layar kredensial Android.
- [ ] Kamera terbuka hanya setelah tombol ditekan dan tidak berjalan diam-diam.
- [ ] Thumbnail kamera tersimpan dan event tercatat.
- [ ] Kontak tersimpan; dialer/SMS meminta konfirmasi pengguna.
- [ ] Ekspor laporan membuka Sharesheet Android.

## Privasi dan ketahanan
- [ ] Tidak ada trafik jaringan atau unggahan data.
- [ ] Riwayat tetap lokal dan dapat dihapus oleh pemilik.
- [ ] Aplikasi tidak menyimpan PIN/pola/sandi layar.
- [ ] Uji setelah reboot, force-stop, hemat baterai, dan izin notifikasi dimatikan.
