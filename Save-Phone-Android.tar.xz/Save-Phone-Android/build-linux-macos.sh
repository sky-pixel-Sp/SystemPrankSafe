#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle tidak ditemukan. Buka folder ini di Android Studio, pasang Android SDK 35 dan JDK 17, lalu Build > Build APK(s)." >&2
  exit 1
fi
gradle assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
