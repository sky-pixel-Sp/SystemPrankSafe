package id.savephone.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public final class NotificationHelper {
    public static final String INCIDENT_CHANNEL = "jaga_hp_incidents";
    public static final String ALARM_CHANNEL = "jaga_hp_alarm";
    private static final int INCIDENT_ID = 301;

    private NotificationHelper() { }

    public static void createChannels(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;

        NotificationChannel incidents = new NotificationChannel(
                INCIDENT_CHANNEL, "Peringatan keamanan", NotificationManager.IMPORTANCE_HIGH);
        incidents.setDescription("Pemberitahuan saat ada percobaan membuka kunci yang gagal.");
        incidents.enableVibration(true);

        NotificationChannel alarm = new NotificationChannel(
                ALARM_CHANNEL, "Alarm Save Phone", NotificationManager.IMPORTANCE_LOW);
        alarm.setDescription("Kontrol alarm yang sedang berjalan.");
        manager.createNotificationChannel(incidents);
        manager.createNotificationChannel(alarm);
    }

    public static void showFailedUnlock(Context context, int attempts, int threshold) {
        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) return;

        createChannels(context);
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending = PendingIntent.getActivity(context, 11, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent startAlarm = new Intent(context, AlarmService.class);
        startAlarm.setAction(AlarmService.ACTION_START);
        PendingIntent alarmPending = PendingIntent.getService(context, 12, startAlarm,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, INCIDENT_CHANNEL)
                : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("Ada percobaan membuka kunci")
                .setContentText("Terdeteksi " + attempts + " percobaan gagal. Batas perlindungan: " + threshold + ".")
                .setStyle(new Notification.BigTextStyle().bigText(
                        "Save Phone mencatat percobaan membuka kunci yang gagal. Alarm dapat dinyalakan dari tombol di bawah."))
                .setContentIntent(openPending)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_lock_idle_alarm, "Bunyikan alarm", alarmPending).build());

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            try {
                manager.notify(INCIDENT_ID, builder.build());
            } catch (SecurityException ignored) {
                // Event history remains available even when notifications are disabled.
            }
        }
    }
}
