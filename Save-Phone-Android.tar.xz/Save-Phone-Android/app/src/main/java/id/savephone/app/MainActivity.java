package id.savephone.app;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int PAGE_HOME = 0;
    private static final int PAGE_EVENTS = 1;
    private static final int PAGE_DEVICE = 2;
    private static final int PAGE_CONTACT = 3;
    private static final int PAGE_MORE = 4;
    private static final int REQUEST_ADMIN = 701;
    private static final int REQUEST_CAMERA = 702;
    private static final int REQUEST_OWNER = 703;
    private static final int REQUEST_NOTIFICATIONS = 704;

    private LinearLayout root;
    private LinearLayout pageContent;
    private int currentPage = PAGE_HOME;
    private EditText contactInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationHelper.createChannels(this);
        requestNotificationPermissionIfNeeded();
        buildPage(PAGE_HOME);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private void buildPage(int page) {
        currentPage = page;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(color(R.color.cream));
        root.setPadding(dp(18), 0, dp(18), 0);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(dp(18), top, dp(18), bottom);
            return insets;
        });

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(0, dp(12), 0, dp(12));
        TextView brand = text("Save Phone", 22, R.color.forest, true);
        header.addView(brand);
        TextView subtitle = text("Perlindungan yang tenang dan sederhana", 12, R.color.muted, false);
        header.addView(subtitle);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        pageContent = new LinearLayout(this);
        pageContent.setOrientation(LinearLayout.VERTICAL);
        pageContent.setPadding(0, 0, 0, dp(18));
        scroll.addView(pageContent, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        buildPageContent(page);
        root.addView(buildBottomNavigation(), new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        root.requestApplyInsets();
    }

    private void buildPageContent(int page) {
        switch (page) {
            case PAGE_EVENTS: buildEventsPage(); break;
            case PAGE_DEVICE: buildDevicePage(); break;
            case PAGE_CONTACT: buildContactPage(); break;
            case PAGE_MORE: buildMorePage(); break;
            default: buildHomePage(); break;
        }
    }

    private void buildHomePage() {
        sectionTitle("Selamat datang");
        TextView intro = text("Jaga perangkatmu dengan langkah sederhana. Kamu tetap memegang kendali atas setiap tindakan.",
                14, R.color.muted, false);
        intro.setLineSpacing(dp(3), 1f);
        pageContent.addView(intro, margin(0, 0, 0, 14));

        boolean active = isAdminActive();
        LinearLayout status = card();
        TextView badge = text(active ? "PERLINDUNGAN AKTIF" : "PERLINDUNGAN BELUM AKTIF", 11,
                active ? R.color.forest : R.color.red_ink, true);
        status.addView(badge, margin(0, 0, 0, 8));
        status.addView(text(active ? "Perangkat terdaftar untuk menerima laporan percobaan kunci yang gagal."
                : "Aktifkan izin administrator perangkat agar Android dapat melaporkan percobaan kunci yang gagal.",
                15, R.color.ink, true), margin(0, 0, 0, 8));
        status.addView(text(active ? "Status: izin administrator diberikan" : "Status: menunggu persetujuan pemilik",
                12, R.color.muted, false));
        pageContent.addView(status, margin(0, 0, 0, 12));

        Button protection = actionButton(active ? "Periksa pengaturan perlindungan" : "Aktifkan perlindungan",
                true, v -> {
                    if (isAdminActive()) buildPage(PAGE_DEVICE);
                    else requestDeviceAdmin();
                });
        pageContent.addView(protection, margin(0, 0, 0, 16));

        sectionTitle("Aksi cepat");
        pageContent.addView(actionButton("Bunyikan alarm", true, v -> startAlarm()), margin(0, 0, 0, 8));
        pageContent.addView(actionButton("Ambil foto bukti", false, v -> openCamera()), margin(0, 0, 0, 8));
        pageContent.addView(actionButton("Kunci layar sekarang", false, v -> lockDevice()), margin(0, 0, 0, 14));

        LinearLayout recent = card();
        recent.addView(text("Kejadian terbaru", 16, R.color.ink, true), margin(0, 0, 0, 8));
        JSONArray events = SecurityStore.getEvents(this);
        if (events.length() == 0) {
            recent.addView(text("Belum ada kejadian. Status keamanan akan tampil di sini setelah tercatat.",
                    13, R.color.muted, false));
        } else {
            JSONObject item = events.optJSONObject(0);
            if (item != null) {
                recent.addView(text(item.optString("title", "Kejadian"), 14, R.color.ink, true));
                recent.addView(text(SecurityStore.formatTime(item.optLong("time", 0)), 12, R.color.muted, false),
                        margin(0, 4, 0, 0));
                recent.addView(text(item.optString("detail", ""), 13, R.color.muted, false), margin(0, 6, 0, 0));
            }
        }
        pageContent.addView(recent, margin(0, 0, 0, 12));

        LinearLayout privacy = card(R.color.sage);
        privacy.addView(text("Privasi tetap terjaga", 15, R.color.forest_dark, true), margin(0, 0, 0, 5));
        privacy.addView(text("Riwayat disimpan di perangkat. Foto hanya diambil saat kamu menekan tombol kamera; aplikasi tidak memotret diam-diam.",
                12, R.color.forest_dark, false));
        pageContent.addView(privacy, margin(0, 0, 0, 8));
    }

    private void buildEventsPage() {
        sectionTitle("Riwayat kejadian");
        pageContent.addView(text("Catatan lokal tentang percobaan kunci, alarm, dan tindakan perlindungan.",
                13, R.color.muted, false), margin(0, 0, 0, 14));
        JSONArray events = SecurityStore.getEvents(this);
        if (events.length() == 0) {
            LinearLayout empty = card();
            empty.addView(text("Belum ada kejadian", 16, R.color.ink, true), margin(0, 0, 0, 5));
            empty.addView(text("Ketika ada aktivitas yang terdeteksi, catatannya akan muncul di halaman ini.",
                    13, R.color.muted, false));
            pageContent.addView(empty);
        } else {
            for (int i = 0; i < events.length(); i++) {
                JSONObject item = events.optJSONObject(i);
                if (item == null) continue;
                LinearLayout entry = card();
                entry.addView(text(item.optString("title", "Kejadian"), 15, R.color.ink, true));
                entry.addView(text(SecurityStore.formatTime(item.optLong("time", 0)), 11, R.color.muted, false),
                        margin(0, 4, 0, 6));
                entry.addView(text(item.optString("detail", ""), 13, R.color.muted, false));
                pageContent.addView(entry, margin(0, 0, 0, 9));
            }
        }
        pageContent.addView(actionButton("Bagikan laporan", true, v -> shareReport()), margin(0, 12, 0, 8));
        pageContent.addView(actionButton("Hapus semua riwayat", false, v -> confirmClearEvents()));
    }

    private void buildDevicePage() {
        sectionTitle("Perangkat");
        pageContent.addView(text(Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE,
                13, R.color.muted, false), margin(0, 0, 0, 14));

        LinearLayout adminCard = card();
        adminCard.addView(text("Izin administrator perangkat", 16, R.color.ink, true), margin(0, 0, 0, 7));
        boolean active = isAdminActive();
        adminCard.addView(text(active ? "Sudah aktif" : "Belum diaktifkan", 14,
                active ? R.color.forest : R.color.red_ink, true), margin(0, 0, 0, 6));
        adminCard.addView(text("Izin ini dibutuhkan agar Android dapat mengirim informasi percobaan membuka kunci yang gagal. Izin tidak memberi aplikasi akses untuk membaca PIN atau sandi.",
                12, R.color.muted, false));
        pageContent.addView(adminCard, margin(0, 0, 0, 10));

        if (!active) {
            pageContent.addView(actionButton("Aktifkan izin administrator", true, v -> requestDeviceAdmin()),
                    margin(0, 0, 0, 10));
        } else {
            pageContent.addView(actionButton("Kunci perangkat", true, v -> lockDevice()), margin(0, 0, 0, 10));
            pageContent.addView(actionButton("Buka pengaturan administrator Android", false,
                    v -> openSecuritySettings()), margin(0, 0, 0, 10));
        }

        LinearLayout trusted = card(R.color.sand);
        trusted.addView(text("Perangkat tepercaya", 15, R.color.ink, true), margin(0, 0, 0, 5));
        trusted.addView(text("Versi awal ini berjalan pada perangkat tempat aplikasi dipasang. Sinkronisasi multi-perangkat dan pelacakan jarak jauh belum diaktifkan.",
                12, R.color.muted, false));
        pageContent.addView(trusted, margin(0, 0, 0, 8));

        pageContent.addView(actionButton("Verifikasi pemilik", false, v -> verifyOwner()), margin(0, 0, 0, 8));
    }

    private void buildContactPage() {
        sectionTitle("Kontak darurat");
        pageContent.addView(text("Simpan nomor orang tepercaya. Save Phone akan membuka aplikasi Telepon atau Pesan agar kamu bisa memeriksa dan mengirimnya sendiri.",
                13, R.color.muted, false), margin(0, 0, 0, 14));

        LinearLayout form = card();
        form.addView(text("Nomor kontak tepercaya", 14, R.color.ink, true), margin(0, 0, 0, 8));
        contactInput = new EditText(this);
        contactInput.setSingleLine(true);
        contactInput.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        contactInput.setText(SecurityStore.getTrustedContact(this));
        contactInput.setHint("Contoh: 08xxxxxxxxxx");
        contactInput.setTextColor(color(R.color.ink));
        contactInput.setHintTextColor(color(R.color.muted));
        contactInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        contactInput.setBackground(roundRect(color(R.color.cream), color(R.color.line), 12));
        form.addView(contactInput, new LinearLayout.LayoutParams(-1, dp(50)));
        form.addView(actionButton("Simpan kontak", true, v -> saveContact()), margin(0, 10, 0, 0));
        pageContent.addView(form, margin(0, 0, 0, 10));

        pageContent.addView(actionButton("Hubungi kontak", false, v -> dialTrustedContact()), margin(0, 0, 0, 8));
        pageContent.addView(actionButton("Bagikan pesan darurat", false, v -> composeEmergencyMessage()), margin(0, 0, 0, 12));

        LinearLayout note = card(R.color.sage);
        note.addView(text("Tidak ada panggilan atau SMS otomatis", 14, R.color.forest_dark, true), margin(0, 0, 0, 5));
        note.addView(text("Kamu akan melihat aplikasi Telepon/Pesan dan tetap harus menekan tombol kirim atau panggil.",
                12, R.color.forest_dark, false));
        pageContent.addView(note);
    }

    private void buildMorePage() {
        sectionTitle("Pengaturan lainnya");
        pageContent.addView(text("Sesuaikan perilaku perlindungan perangkat.", 13, R.color.muted, false),
                margin(0, 0, 0, 14));

        LinearLayout thresholdCard = card();
        thresholdCard.addView(text("Batas percobaan kunci gagal", 15, R.color.ink, true), margin(0, 0, 0, 5));
        thresholdCard.addView(text("Peringatan muncul setelah jumlah percobaan yang dipilih. Android/OEM tetap menentukan kebijakan penguncian layar.",
                12, R.color.muted, false), margin(0, 0, 0, 8));
        Spinner thresholdSpinner = spinner(new String[]{"2 kali", "3 kali", "5 kali"});
        int thresholdIndex = SecurityStore.getThreshold(this) == 2 ? 0 :
                (SecurityStore.getThreshold(this) == 5 ? 2 : 1);
        thresholdSpinner.setSelection(thresholdIndex);
        thresholdSpinner.setOnItemSelectedListener(new SimpleSelectionListener(position -> {
            int value = position == 0 ? 2 : (position == 2 ? 5 : 3);
            SecurityStore.setThreshold(this, value);
        }));
        thresholdCard.addView(thresholdSpinner);
        pageContent.addView(thresholdCard, margin(0, 0, 0, 10));

        LinearLayout alarmCard = card();
        alarmCard.addView(text("Durasi alarm", 15, R.color.ink, true), margin(0, 0, 0, 5));
        alarmCard.addView(text("Alarm berhenti otomatis setelah durasi ini. Alarm bisa dihentikan lebih awal dari notifikasi.",
                12, R.color.muted, false), margin(0, 0, 0, 8));
        Spinner durationSpinner = spinner(new String[]{"30 detik", "60 detik", "90 detik"});
        int durationIndex = SecurityStore.getAlarmSeconds(this) == 30 ? 0 :
                (SecurityStore.getAlarmSeconds(this) == 90 ? 2 : 1);
        durationSpinner.setSelection(durationIndex);
        durationSpinner.setOnItemSelectedListener(new SimpleSelectionListener(position -> {
            int value = position == 0 ? 30 : (position == 2 ? 90 : 60);
            SecurityStore.setAlarmSeconds(this, value);
        }));
        alarmCard.addView(durationSpinner);
        pageContent.addView(alarmCard, margin(0, 0, 0, 10));

        pageContent.addView(actionButton("Verifikasi pemilik", true, v -> verifyOwner()), margin(0, 0, 0, 8));
        pageContent.addView(actionButton("Buka pengaturan keamanan Android", false, v -> openSecuritySettings()),
                margin(0, 0, 0, 8));

        LinearLayout about = card(R.color.sage);
        about.addView(text("Tentang Save Phone", 15, R.color.forest_dark, true), margin(0, 0, 0, 5));
        about.addView(text("Versi 1.0.0 · Data kejadian disimpan lokal. Aplikasi tidak mengunggah foto, lokasi, atau riwayat ke server.",
                12, R.color.forest_dark, false));
        pageContent.addView(about, margin(0, 0, 0, 10));
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, dp(8), 0, dp(8));
        nav.setBackground(roundRect(color(R.color.paper), color(R.color.line), 18));
        String[] labels = {"Beranda", "Riwayat", "Perangkat", "Kontak", "Lainnya"};
        for (int i = 0; i < labels.length; i++) {
            final int target = i;
            TextView item = text(labels[i], 10, currentPage == i ? R.color.forest : R.color.muted,
                    currentPage == i);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(2), dp(8), dp(2), dp(8));
            if (currentPage == i) item.setBackground(roundRect(color(R.color.sage), Color.TRANSPARENT, 10));
            nav.addView(item, new LinearLayout.LayoutParams(0, dp(42), 1f));
            item.setOnClickListener(v -> buildPage(target));
        }
        return nav;
    }

    private void sectionTitle(String value) {
        pageContent.addView(text(value, 23, R.color.ink, true), margin(0, 0, 0, 8));
    }

    private LinearLayout card() { return card(R.color.paper); }

    private LinearLayout card(int backgroundColor) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(15), dp(14), dp(15), dp(14));
        layout.setBackground(roundRect(color(backgroundColor), color(R.color.line), 16));
        return layout;
    }

    private TextView text(String value, int size, int colorId, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color(colorId));
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setIncludeFontPadding(true);
        return view;
    }

    private Button actionButton(String label, boolean primary, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(color(primary ? R.color.paper : R.color.forest_dark));
        button.setPadding(dp(14), dp(6), dp(14), dp(6));
        button.setBackground(roundRect(color(primary ? R.color.forest : R.color.sage),
                primary ? Color.TRANSPARENT : color(R.color.line), 13));
        button.setOnClickListener(listener);
        return button;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        if (stroke != Color.TRANSPARENT) drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams margin(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private int color(int id) { return getResources().getColor(id); }

    private boolean isAdminActive() {
        DevicePolicyManager manager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        return manager != null && manager.isAdminActive(new ComponentName(this, ProtectionAdminReceiver.class));
    }

    private void requestDeviceAdmin() {
        ComponentName admin = new ComponentName(this, ProtectionAdminReceiver.class);
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Izin ini diperlukan untuk menerima laporan percobaan kunci yang gagal dan menyediakan tombol kunci perangkat.");
        startActivityForResult(intent, REQUEST_ADMIN);
    }

    private void lockDevice() {
        if (!isAdminActive()) {
            Toast.makeText(this, "Aktifkan izin administrator terlebih dahulu.", Toast.LENGTH_LONG).show();
            requestDeviceAdmin();
            return;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Kunci layar sekarang?")
                .setMessage("Layar perangkat akan langsung dikunci. Buka kembali dengan metode kunci perangkat yang biasa.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Kunci layar", (dialog, which) -> {
                    try {
                        DevicePolicyManager manager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                        manager.lockNow();
                        SecurityStore.addEvent(this, "Layar dikunci", "Perintah kunci dijalankan dari aplikasi.");
                    } catch (SecurityException e) {
                        Toast.makeText(this, "Android menolak perintah kunci. Periksa izin administrator.", Toast.LENGTH_LONG).show();
                    }
                }).show();
    }

    private void startAlarm() {
        Intent intent = new Intent(this, AlarmService.class);
        intent.setAction(AlarmService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            Toast.makeText(this, "Alarm dinyalakan.", Toast.LENGTH_SHORT).show();
        } catch (RuntimeException e) {
            Toast.makeText(this, "Android tidak mengizinkan alarm dimulai. Coba dari aplikasi yang terbuka.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void openCamera() {
        Intent capture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (capture.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "Aplikasi kamera tidak ditemukan.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startActivityForResult(capture, REQUEST_CAMERA);
        } catch (RuntimeException e) {
            Toast.makeText(this, "Kamera tidak dapat dibuka.", Toast.LENGTH_LONG).show();
        }
    }

    private void saveCameraThumbnail(Intent data) {
        if (data == null || data.getExtras() == null) return;
        Object value = data.getExtras().get("data");
        if (!(value instanceof Bitmap)) {
            Toast.makeText(this, "Kamera tidak mengembalikan foto.", Toast.LENGTH_LONG).show();
            return;
        }
        File directory = new File(getFilesDir(), "captures");
        if (!directory.exists() && !directory.mkdirs()) {
            Toast.makeText(this, "Folder foto tidak dapat dibuat.", Toast.LENGTH_LONG).show();
            return;
        }
        File output = new File(directory, "bukti_" + System.currentTimeMillis() + ".jpg");
        try (FileOutputStream stream = new FileOutputStream(output)) {
            ((Bitmap) value).compress(Bitmap.CompressFormat.JPEG, 88, stream);
            SecurityStore.addEvent(this, "Foto bukti disimpan", "Foto thumbnail kamera disimpan di penyimpanan privat aplikasi: " + output.getName());
            Toast.makeText(this, "Foto bukti tersimpan di aplikasi.", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Gagal menyimpan foto.", Toast.LENGTH_LONG).show();
        }
    }

    private void verifyOwner() {
        KeyguardManager keyguard = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (keyguard == null || !keyguard.isDeviceSecure()) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Kunci layar belum disiapkan")
                    .setMessage("Atur PIN, pola, atau sandi layar di pengaturan Android terlebih dahulu. Verifikasi pemilik memakai metode yang sudah disediakan Android.")
                    .setPositiveButton("Buka pengaturan", (d, w) -> openSecuritySettings())
                    .setNegativeButton("Tutup", null).show();
            return;
        }
        Intent confirm = keyguard.createConfirmDeviceCredentialIntent(
                "Verifikasi pemilik", "Masukkan kredensial layar perangkat untuk melanjutkan.");
        if (confirm != null) {
            startActivityForResult(confirm, REQUEST_OWNER);
        } else {
            Toast.makeText(this, "Layar verifikasi tidak tersedia pada perangkat ini.", Toast.LENGTH_LONG).show();
        }
    }

    private void openSecuritySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));
        } catch (RuntimeException e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void saveContact() {
        if (contactInput == null) return;
        String number = contactInput.getText().toString().trim();
        if (number.length() < 5) {
            Toast.makeText(this, "Masukkan nomor telepon yang valid.", Toast.LENGTH_LONG).show();
            return;
        }
        SecurityStore.setTrustedContact(this, number);
        SecurityStore.addEvent(this, "Kontak darurat diperbarui", "Nomor kontak tepercaya disimpan di perangkat.");
        Toast.makeText(this, "Kontak tersimpan.", Toast.LENGTH_SHORT).show();
    }

    private boolean hasTrustedContact() {
        String number = SecurityStore.getTrustedContact(this);
        if (number == null || number.trim().length() < 5) {
            Toast.makeText(this, "Simpan nomor kontak tepercaya terlebih dahulu.", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void dialTrustedContact() {
        if (!hasTrustedContact()) return;
        Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(SecurityStore.getTrustedContact(this))));
        startActivity(dial);
    }

    private void composeEmergencyMessage() {
        if (!hasTrustedContact()) return;
        String number = SecurityStore.getTrustedContact(this);
        Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)));
        sms.putExtra("sms_body", "Hai, saya membutuhkan bantuan. Mohon hubungi saya.");
        try {
            startActivity(sms);
        } catch (RuntimeException e) {
            Toast.makeText(this, "Aplikasi pesan tidak tersedia.", Toast.LENGTH_LONG).show();
        }
    }

    private void shareReport() {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "Laporan Save Phone");
        share.putExtra(Intent.EXTRA_TEXT, SecurityStore.exportEvents(this));
        startActivity(Intent.createChooser(share, "Bagikan laporan"));
    }

    private void confirmClearEvents() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Hapus semua riwayat?")
                .setMessage("Catatan kejadian di aplikasi akan dihapus. Tindakan ini tidak dapat dibatalkan.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (d, w) -> {
                    SecurityStore.clearEvents(this);
                    buildPage(PAGE_EVENTS);
                    Toast.makeText(this, "Riwayat dihapus.", Toast.LENGTH_SHORT).show();
                }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAMERA && resultCode == RESULT_OK) {
            saveCameraThumbnail(data);
        } else if (requestCode == REQUEST_OWNER) {
            if (resultCode == RESULT_OK) {
                SecurityStore.addEvent(this, "Verifikasi pemilik berhasil", "Kredensial layar perangkat berhasil diverifikasi oleh Android.");
                Toast.makeText(this, "Pemilik berhasil diverifikasi oleh Android.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Verifikasi dibatalkan atau gagal.", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQUEST_ADMIN) {
            buildPage(currentPage);
        }
    }

    private interface SelectionAction { void selected(int position); }

    private static class SimpleSelectionListener implements android.widget.AdapterView.OnItemSelectedListener {
        private final SelectionAction action;
        SimpleSelectionListener(SelectionAction action) { this.action = action; }
        @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            action.selected(position);
        }
        @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
    }
}
