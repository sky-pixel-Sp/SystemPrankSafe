package id.savephone.app;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.Intent;
import android.os.UserHandle;

/** Receives failed/successful device-credential events after the owner enables device-admin access. */
public class ProtectionAdminReceiver extends DeviceAdminReceiver {
    @Override
    public void onPasswordFailed(Context context, Intent intent, UserHandle user) {
        super.onPasswordFailed(context, intent, user);
        DevicePolicyManager policy = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        int attempts = 0;
        try {
            if (policy != null) attempts = policy.getCurrentFailedPasswordAttempts();
        } catch (SecurityException ignored) {
            // Some OEM builds may not expose the counter to this administrator.
        }

        int threshold = SecurityStore.getThreshold(context);
        SecurityStore.addEvent(context, "Percobaan membuka kunci gagal",
                "Perangkat melaporkan " + attempts + " percobaan gagal. Batas yang dipilih: " + threshold + ".");

        if (attempts >= threshold && !SecurityStore.hasAlerted(context)) {
            SecurityStore.setAlerted(context, true);
            NotificationHelper.showFailedUnlock(context, attempts, threshold);
        }
    }

    @Override
    public void onPasswordSucceeded(Context context, Intent intent, UserHandle user) {
        super.onPasswordSucceeded(context, intent, user);
        if (SecurityStore.hasAlerted(context)) {
            SecurityStore.addEvent(context, "Perangkat berhasil dibuka",
                    "Autentikasi perangkat berhasil setelah percobaan yang gagal.");
        }
        SecurityStore.setAlerted(context, false);
    }
}
