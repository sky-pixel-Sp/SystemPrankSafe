package id.savephone.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;

/** Small, local-only store for preferences and the incident timeline. */
public final class SecurityStore {
    private static final String PREFS = "jaga_hp_preferences";
    private static final String KEY_EVENTS = "events_json";
    private static final String KEY_THRESHOLD = "attempt_threshold";
    private static final String KEY_ALARM_SECONDS = "alarm_seconds";
    private static final String KEY_CONTACT = "trusted_contact";
    private static final String KEY_ALERT_SENT = "alert_sent_for_current_unlock";
    private static final int MAX_EVENTS = 100;

    private SecurityStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int getThreshold(Context context) {
        return prefs(context).getInt(KEY_THRESHOLD, 3);
    }

    public static void setThreshold(Context context, int value) {
        int safeValue = (value == 2 || value == 5) ? value : 3;
        prefs(context).edit().putInt(KEY_THRESHOLD, safeValue).apply();
    }

    public static int getAlarmSeconds(Context context) {
        return prefs(context).getInt(KEY_ALARM_SECONDS, 60);
    }

    public static void setAlarmSeconds(Context context, int value) {
        int safeValue = (value == 30 || value == 90) ? value : 60;
        prefs(context).edit().putInt(KEY_ALARM_SECONDS, safeValue).apply();
    }

    public static String getTrustedContact(Context context) {
        return prefs(context).getString(KEY_CONTACT, "");
    }

    public static void setTrustedContact(Context context, String number) {
        prefs(context).edit().putString(KEY_CONTACT, number == null ? "" : number.trim()).apply();
    }

    public static boolean hasAlerted(Context context) {
        return prefs(context).getBoolean(KEY_ALERT_SENT, false);
    }

    public static void setAlerted(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_ALERT_SENT, value).apply();
    }

    public static synchronized void addEvent(Context context, String title, String detail) {
        JSONArray old = getEvents(context);
        JSONArray updated = new JSONArray();
        JSONObject entry = new JSONObject();
        try {
            entry.put("title", title == null ? "Kejadian" : title);
            entry.put("detail", detail == null ? "" : detail);
            entry.put("time", System.currentTimeMillis());
            updated.put(entry);
            for (int i = 0; i < old.length() && updated.length() < MAX_EVENTS; i++) {
                JSONObject item = old.optJSONObject(i);
                if (item != null) updated.put(item);
            }
            prefs(context).edit().putString(KEY_EVENTS, updated.toString()).apply();
        } catch (JSONException ignored) {
            // Keep the previous history if local storage cannot be updated.
        }
    }

    public static JSONArray getEvents(Context context) {
        String raw = prefs(context).getString(KEY_EVENTS, "[]");
        try {
            return new JSONArray(raw == null ? "[]" : raw);
        } catch (JSONException ignored) {
            return new JSONArray();
        }
    }

    public static void clearEvents(Context context) {
        prefs(context).edit().remove(KEY_EVENTS).apply();
    }

    public static String formatTime(long millis) {
        return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                .format(new Date(millis));
    }

    public static String exportEvents(Context context) {
        JSONArray events = getEvents(context);
        StringBuilder result = new StringBuilder("LAPORAN SAVE PHONE\n");
        result.append("Dibuat: ").append(formatTime(System.currentTimeMillis())).append("\n\n");
        if (events.length() == 0) return result.append("Belum ada kejadian tercatat.\n").toString();
        for (int i = 0; i < events.length(); i++) {
            JSONObject item = events.optJSONObject(i);
            if (item == null) continue;
            result.append("• ").append(item.optString("title", "Kejadian")).append("\n")
                    .append(formatTime(item.optLong("time", 0))).append("\n")
                    .append(item.optString("detail", "")).append("\n\n");
        }
        result.append("Catatan tersimpan secara lokal di perangkat.\n");
        return result.toString();
    }
}
