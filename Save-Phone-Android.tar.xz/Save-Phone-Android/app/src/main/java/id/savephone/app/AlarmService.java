package id.savephone.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/** Visible, user-started alarm. It never changes the device volume or suppresses system controls. */
public class AlarmService extends Service {
    public static final String ACTION_START = "id.savephone.app.action.START_ALARM";
    public static final String ACTION_STOP = "id.savephone.app.action.STOP_ALARM";
    private static final int NOTIFICATION_ID = 302;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Ringtone ringtone;
    private ToneGenerator fallbackTone;
    private final Runnable autoStop = this::stopAlarm;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopAlarm();
            return START_NOT_STICKY;
        }

        NotificationHelper.createChannels(this);
        Notification notification = buildRunningNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }

        playAlarmTone();
        handler.removeCallbacks(autoStop);
        handler.postDelayed(autoStop, SecurityStore.getAlarmSeconds(this) * 1000L);
        SecurityStore.addEvent(this, "Alarm dinyalakan", "Alarm berjalan dengan durasi maksimal "
                + SecurityStore.getAlarmSeconds(this) + " detik.");
        return START_NOT_STICKY;
    }

    private Notification buildRunningNotification() {
        Intent stopIntent = new Intent(this, AlarmService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 33, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, NotificationHelper.ALARM_CHANNEL)
                : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Alarm Save Phone aktif")
                .setContentText("Alarm berhenti otomatis. Kamu juga dapat menghentikannya di sini.")
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_media_pause, "Matikan alarm", stopPending).build())
                .build();
    }

    private void playAlarmTone() {
        stopToneOnly();
        try {
            Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (alarmUri != null) {
                ringtone = RingtoneManager.getRingtone(getApplicationContext(), alarmUri);
                if (ringtone != null) {
                    ringtone.setStreamType(AudioManager.STREAM_ALARM);
                    ringtone.play();
                    return;
                }
            }
        } catch (RuntimeException ignored) {
            // Use the built-in tone generator as a fallback.
        }
        try {
            fallbackTone = new ToneGenerator(AudioManager.STREAM_ALARM, 85);
            fallbackTone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,
                    SecurityStore.getAlarmSeconds(this) * 1000);
        } catch (RuntimeException ignored) {
            // The service still exposes the stop notification if audio playback is unavailable.
        }
    }

    private void stopToneOnly() {
        if (ringtone != null) {
            try { ringtone.stop(); } catch (RuntimeException ignored) { }
            ringtone = null;
        }
        if (fallbackTone != null) {
            try { fallbackTone.stopTone(); fallbackTone.release(); } catch (RuntimeException ignored) { }
            fallbackTone = null;
        }
    }

    private void stopAlarm() {
        handler.removeCallbacks(autoStop);
        stopToneOnly();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(autoStop);
        stopToneOnly();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
