# Save Phone — Android Anti-Theft Companion

Aplikasi Android native untuk membantu pemilik melindungi perangkat dengan tampilan sederhana, bersih, dan ramah pengguna (putih gading, hijau lembut, krem). Bukan aplikasi bertema cyber.

## Menu
1. **Beranda** — status perlindungan, aksi cepat, dan kejadian terbaru.
2. **Riwayat** — catatan lokal percobaan kunci, alarm, foto bukti, dan tindakan pemilik; laporan dapat dibagikan.
3. **Perangkat** — aktivasi Device Admin, kunci perangkat, verifikasi pemilik, dan status perlindungan.
4. **Kontak darurat** — simpan nomor tepercaya, buka dialer, atau susun pesan darurat. Pengguna tetap mengonfirmasi panggilan/pengiriman sendiri.
5. **Pengaturan** — ambang percobaan (2/3/5 kali), durasi alarm (30/60/90 detik), verifikasi pemilik, dan privasi.

## Fitur yang diimplementasikan di source
- `DeviceAdminReceiver` dengan kebijakan `watch-login` untuk menerima callback percobaan kredensial gagal setelah pemilik mengaktifkan administrator perangkat.
- Riwayat kejadian lokal di `SharedPreferences` (maksimal 100 catatan).
- Notifikasi saat ambang percobaan gagal tercapai.
- Alarm foreground service dengan durasi pilihan dan kontrol berhenti dari notifikasi.
- Kunci perangkat melalui `DevicePolicyManager.lockNow()` setelah izin administrator diaktifkan.
- Verifikasi pemilik melalui kredensial sistem Android; aplikasi tidak membaca/menyimpan PIN, pola, atau sandi perangkat.
- Kontak tepercaya disimpan lokal. Panggilan/SMS dikonfirmasi pengguna melalui aplikasi sistem.
- Tombol kamera membuka aplikasi kamera sistem secara terlihat; thumbnail yang dikembalikan kamera dapat disimpan privat.
- Ekspor riwayat melalui Android Sharesheet.

## Batasan Android yang penting
- Tidak ada pemotretan diam-diam. Kamera mengikuti izin dan pembatasan Android untuk penggunaan latar belakang. Pengambilan foto harus dimulai secara terlihat oleh pengguna.
- OEM/versi Android menentukan perilaku callback percobaan kunci; tidak dijamin sama pada semua perangkat.
- Alarm menghormati kontrol volume, mode senyap, DND, dan kebijakan sistem. Aplikasi tidak memblokir tombol volume.
- Aplikasi biasa tidak dapat mematikan perangkat secara paksa, membaca PIN, atau melewati autentikasi pemilik.
- Daftar perangkat tepercaya pada versi ini adalah informasi/status lokal; pairing dan sinkronisasi lintas perangkat belum tersedia.
- Tidak ada server, tracking lokasi, pengiriman foto otomatis, atau unggahan data.

## Persyaratan build
- Android Studio, Android SDK Platform 35, JDK 17.
- Android Gradle Plugin 8.7.3 dan Gradle 8.9.
- Minimum Android 8.0 / API 26; target SDK 35.

## Build APK debug
Buka folder `Save-Phone-Android` di Android Studio, sinkronkan Gradle, lalu pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Alternatif terminal: `gradle assembleDebug`.

Jika Gradle wrapper tersedia, gunakan `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). APK debug yang berhasil dibangun berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Identitas aplikasi
- Nama aplikasi: **Save Phone**
- Application ID: `id.savephone.app`
- Namespace: `id.savephone.app`
- Versi: `1.0.0` (versionCode 1)

## Build APK otomatis melalui GitHub Actions
Workflow `.github/workflows/build-apk.yml` disertakan. Setelah seluruh isi folder proyek diunggah ke repository GitHub pada branch `main` atau `master`, workflow akan berjalan saat push. Workflow juga dapat dijalankan manual melalui tab **Actions** → **Build Save Phone APK** → **Run workflow**. Jika sukses, unduh artifact bernama `Save-Phone-debug-apk` dari hasil run. Workflow ini belum dijalankan dari sesi ini; status sukses baru dapat dinyatakan setelah GitHub menyelesaikannya.
