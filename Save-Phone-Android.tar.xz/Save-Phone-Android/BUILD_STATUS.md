# Save Phone — Build status

## Completed in this workspace
- Renamed app display name, Gradle project, namespace, application ID, Java package, and notification strings to **Save Phone**.
- Application ID: `id.savephone.app`.
- Android source project and resource files are present.
- Offline structural validation: passed (XML parsing, manifest component/source matching, Device Admin declarations, required source files).
- ZIP archive integrity: checked after packaging.
- Added GitHub Actions workflow `.github/workflows/build-apk.yml` to build a debug APK on pushes to `main`/`master` or manual workflow dispatch, then upload the APK as an artifact.

## Not completed / not verified
- A local APK was **not** built in this workspace. The environment has Java 21 but no Gradle executable, Android SDK, `android.jar`, or Gradle wrapper; direct download attempts failed because DNS/network access is unavailable.
- The GitHub Actions workflow has been authored but not run. It requires this source folder to be pushed to a GitHub repository and Actions enabled.
- No installation or runtime test on a physical Android device has been performed.

## Build output when the workflow succeeds
`app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions artifact name: `Save-Phone-debug-apk`.
